<template>
  <my-login />
</template>

<script>
export default {
  name: 'login'
};
</script>
